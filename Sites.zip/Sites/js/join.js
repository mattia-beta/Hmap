$(document).ready(function()
{
	    $('#myTab a').click(function (e) 
	    {
		    e.preventDefault();
		    $(this).tab('show');
	    });
	    
	    $('#myTab a:last').tab('show');
});