<?
	
	$db = mysql_connect('localhost', 'django', 'django', 'HMAP'); 
	$dbi = @mysqli_connect('localhost', 'django', 'django', 'HMAP'); 

	if (mysqli_connect_error()) 
	{
		die('Could not connect to the database'); 
	}
	
?>