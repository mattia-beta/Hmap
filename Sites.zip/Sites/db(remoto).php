<?
	
	$db = mysql_connect('sql.mattiabenedetti.net', 'mattiabe61011', 'matt39543', 'mattiabe61011'); 
	$dbi = @mysqli_connect('sql.mattiabenedetti.net', 'mattiabe61011', 'matt39543', 'mattiabe61011'); 

	if (mysqli_connect_error()) 
	{
		die('Could not connect to the database'); 
	}
	
?>